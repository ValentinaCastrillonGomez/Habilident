const { EC2Client, DescribeSpotInstanceRequestsCommand, DescribeInstancesCommand, StartInstancesCommand } = require('@aws-sdk/client-ec2');
const axios = require('axios').default;

const client = new EC2Client({ region: process.env.AWS_REGION });

exports.handler = async (event) => selectRequestInstance()
    .then((instanceId) => startInstance(instanceId)
        .then(() => new Promise((resolve) => { setTimeout(resolve, 3000) }))
        .then(() => selectInstance(instanceId)))
    .then((publicIpAddress) => responseInteraction(publicIpAddress, JSON.parse(event.Records[0].Sns.Message)))
    .catch((error) => {
        console.log(`Fallo exitosamente: ${error.message}`);
    });

const selectRequestInstance = () =>
    client.send(new DescribeSpotInstanceRequestsCommand({
        Filters: [{ Name: 'state', Values: ['active', 'disabled'] }]
    })).then((data) => data.SpotInstanceRequests[0].InstanceId);

const startInstance = (instanceId) =>
    client.send(new StartInstancesCommand({
        InstanceIds: [instanceId]
    }));

const selectInstance = (instanceId) =>
    client.send(new DescribeInstancesCommand({
        clientInstanceIds: [instanceId]
    })).then((data) => data.Reservations[0].Instances[0].PublicIpAddress);

const responseInteraction = (response, body) =>
    axios.patch(`https://discord.com/api/v10/webhooks/${body.application_id}/${body.token}/messages/@original`, { "content": response });
